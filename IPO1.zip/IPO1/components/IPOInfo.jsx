import React, { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import './IPOInfo.css';

const IPOInfo = () => {
  const { id } = useParams();
  const navigate = useNavigate();

  const initialData = {
    companyLogo: 'company-logo-url',
    companyName: 'Vodafone Idea',
    priceBand: 'Not Issued',
    open: 'Not Issued',
    close: 'Not Issued',
    issueSize: '2300 Cr.',
    issueType: '',
    listingDate: 'Not Issued',
    status: '',
    ipoPrice: '₹ 383',
    listingPrice: '₹ 435',
    listingGain: '13.58%',
    listingDateNew: '2024-05-30',
    cmp: '₹410',
    currentReturn: '7.05%',
    rhp: '',
    drhp: ''
  };

  const [ipoDetails, setIpoDetails] = useState(initialData);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setIpoDetails({ ...ipoDetails, [name]: value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log('Updated IPO Details:', ipoDetails);
  };

  return (
    <div className='main'>
    <div className="header-content">
        <div >
          <h2>Upcoming IPO Information</h2>
          <p>Manage your IPO Details</p>
        </div>
        <div className="form-buttons">
          <button type="submit" form="ipoForm">Register</button>
          <button type="button" onClick={() => navigate(-1)}>Cancel</button>
        </div>
    </div>
      <div className="ipo-content">
        <div className='ipo-sidebar'>
        <ul className="menu">
        <li className="active"> IPO Information</li>
        <li>IPO info</li>
        </ul>
        </div>
        <div className="ipo-info">
        <div className='ipo-header'>
            <h2>IPO Information</h2>
            <p>Enter IPO Details</p>
        </div>
      <form id="ipoForm" onSubmit={handleSubmit}>
      <div className="form-group sub-header">
            <label>Company Logo</label>
            <div className="company-logo">
              <img src={ipoDetails.companyLogo} alt="Company Logo" />
              <label >{ipoDetails.companyName}</label>
              <button type="submit">Upload Logo</button>
              <button type="button">Delete</button>
            </div>
          </div>
        <div className="form-grid">
          <div className="form-group">
            <label>Company Name</label>
            <input
              type="text"
              name="companyName"
              value={ipoDetails.companyName}
              onChange={handleChange}
            />
          </div>
          <div className="form-group">
            <label>Price Band</label>
            <input
              type="text"
              name="priceBand"
              value={ipoDetails.priceBand}
              onChange={handleChange}
            />
          </div>
          <div className="form-group">
            <label>Open</label>
            <input
              type="text"
              name="open"
              value={ipoDetails.open}
              onChange={handleChange}
            />
          </div>
          <div className="form-group">
            <label>Close</label>
            <input
              type="text"
              name="close"
              value={ipoDetails.close}
              onChange={handleChange}
            />
          </div>
          <div className="form-group">
            <label>Issue Size</label>
            <input
              type="text"
              name="issueSize"
              value={ipoDetails.issueSize}
              onChange={handleChange}
            />
          </div>
          <div className="form-group">
            <label>Issue Type</label>
            <select name="issueType" value={ipoDetails.issueType} onChange={handleChange}>
              <option value="">Select Type</option>
              <option value="Book Built">Book Built</option>
              <option value="Fixed Price">Fixed Price</option>
            </select>
          </div>
          <div className="form-group">
            <label>Listing Date</label>
            <input
              type="text"
              name="listingDate"
              value={ipoDetails.listingDate}
              onChange={handleChange}
            />
          </div>
          <div className="form-group">
            <label>Status</label>
            <input
              type="text"
              name="status"
              value={ipoDetails.status}
              onChange={handleChange}
            />
          </div>
        </div>
        <h3>New Listed IPO Details (When IPO Get Listed)</h3>
        <div className="form-grid">
          <div className="form-group">
            <label>IPO Price</label>
            <input
              type="text"
              name="ipoPrice"
              value={ipoDetails.ipoPrice}
              onChange={handleChange}
            />
          </div>
          <div className="form-group">
            <label>Listing Price</label>
            <input
              type="text"
              name="listingPrice"
              value={ipoDetails.listingPrice}
              onChange={handleChange}
            />
          </div>
          <div className="form-group">
            <label>Listing Gain</label>
            <input
              type="text"
              name="listingGain"
              value={ipoDetails.listingGain}
              onChange={handleChange}
            />
          </div>
          <div className="form-group">
            <label>Listing Date</label>
            <input
              type="text"
              name="listingDateNew"
              value={ipoDetails.listingDateNew}
              onChange={handleChange}
            />
          </div>
          <div className="form-group">
            <label>CMP</label>
            <input
              type="text"
              name="cmp"
              value={ipoDetails.cmp}
              onChange={handleChange}
            />
          </div>
          <div className="form-group">
            <label>Current Return</label>
            <input
              type="text"
              name="currentReturn"
              value={ipoDetails.currentReturn}
              onChange={handleChange}
            />
          </div>
          <div className="form-group">
            <label>RHP</label>
            <input
              type="text"
              name="rhp"
              value={ipoDetails.rhp}
              onChange={handleChange}
            />
          </div>
          <div className="form-group">
            <label>DRHP</label>
            <input
              type="text"
              name="drhp"
              value={ipoDetails.drhp}
              onChange={handleChange}
            />
          </div>
        </div>
      </form>
    </div>
      </div>
    </div>
  );
};

export default IPOInfo;

import React from 'react';
import './Sidebar.css';

const Sidebar = () => {
  return (
    <div className="sidebar">
      <div className="logo">Bluestock Fintech</div>
      <ul className="menu">
        <li>Food Order</li>
        <li className="active">Manage IPO</li>
        <li>IPO Subscription</li>
        <li>IPO Allotment</li>
        <li>Settings</li>
        <li>API Manager</li>
        <li>Accounts</li>
        <li>Help</li>
      </ul>
    </div>
  );
}

export default Sidebar;

import React from 'react';
import './Header.css';

const Header = ({ searchTerm, setSearchTerm }) => {
  const handleSearchChange = (event) => {
    setSearchTerm(event.target.value);
  };

  return (
    <div className="header">
      <div className="search-container">
        <input
          type="text"
          placeholder="Search..."
          value={searchTerm}
          onChange={handleSearchChange}
          className="search-input"
        />
      </div>
      <div className="header-right">
        <div className="notification-icon">
          <i className="fa fa-bell"></i>
        </div>
        <div className="profile">
          <img  alt="Profile" className="profile-photo" />
          <span className="profile-name">Hi, Vishal</span>
          <span className="notification-icon">🔔</span>
        </div>
      </div>
    </div>
  );
};

export default Header;

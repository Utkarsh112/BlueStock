import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import './IPOList.css';

const IPOList = ({ searchTerm }) => {
  const initialData = [
    {
      company: "Adani Power",
      priceBand: "₹ 129 - 136",
      open: "2024-06-03",
      close: "2024-06-05",
      issueSize: "130.15 Cr.",
      issueType: "Book Built",
      listingDate: "2024-06-10",
      status: "Ongoing"
    },
    {
      company: "VBL LTD",
      priceBand: "₹ 129 - 136",
      open: "2024-06-03",
      close: "2024-06-05",
      issueSize: "130.15 Cr.",
      issueType: "Book Built",
      listingDate: "2024-06-10",
      status: "Coming"
    },
    {
      company: "Tata Motor",
      priceBand: "₹ 129 - 136",
      open: "2024-06-03",
      close: "2024-06-05",
      issueSize: "130.15 Cr.",
      issueType: "Book Built",
      listingDate: "2024-06-10",
      status: "New Listed"
    },
    {
      company: "Indus Tower",
      priceBand: "₹ 129 - 136",
      open: "2024-06-03",
      close: "2024-06-05",
      issueSize: "130.15 Cr.",
      issueType: "Book Built",
      listingDate: "2024-06-10",
      status: "Coming"
    },
    {
      company: "BSE India",
      priceBand: "₹ 129 - 136",
      open: "2024-06-03",
      close: "2024-06-05",
      issueSize: "130.15 Cr.",
      issueType: "Book Built",
      listingDate: "2024-06-10",
      status: "New Listed"
    }
  ];

  const [ipoData, setIpoData] = useState(initialData);
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage] = useState(5);
  const navigate = useNavigate();

  const handleUpdate = (id) => {
    navigate(`/ipo-info/${id}`);
  };

  const handleDelete = (index) => {
    setIpoData(prevData => prevData.filter((_, i) => i !== index));
  };

  const handleView = (index) => {
    console.log(`View button clicked for index ${index}`);
  };

  const filteredData = ipoData.filter(item => 
    item.company.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const indexOfLastItem = currentPage * itemsPerPage;
  const indexOfFirstItem = indexOfLastItem - itemsPerPage;
  const currentData = filteredData.slice(indexOfFirstItem, indexOfLastItem);

  const pageNumbers = [];
  for (let i = 1; i <= Math.ceil(filteredData.length / itemsPerPage); i++) {
    pageNumbers.push(i);
  }

  const handleClick = (pageNumber) => {
    setCurrentPage(pageNumber);
  };

  const handlePrevPage = () => {
    setCurrentPage(prevPage => Math.max(prevPage - 1, 1));
  };

  const handleNextPage = () => {
    setCurrentPage(prevPage => Math.min(prevPage + 1, pageNumbers.length));
  };

  return (
    <div className="ipo-list">
      <h2>Upcoming IPO | Dashboard</h2>
      <table>
        <thead>
          <tr>
            <th>Company</th>
            <th>Price Band</th>
            <th>Open</th>
            <th>Close</th>
            <th>Issue Size</th>
            <th>Issue Type</th>
            <th>Listing Date</th>
            <th>Status</th>
            <th>Action</th>
            <th>Delete/View</th>
          </tr>
        </thead>
        <tbody className='ipo-body'> 
          {currentData.map((ipo, index) => (
            <tr key={index}>
              <td>{ipo.company}</td>
              <td>{ipo.priceBand}</td>
              <td>{ipo.open}</td>
              <td>{ipo.close}</td>
              <td>{ipo.issueSize}</td>
              <td>{ipo.issueType}</td>
              <td>{ipo.listingDate}</td>
              <td>
                <span className={`status ${ipo.status.toLowerCase().replace(" ", "-")}`}>
                  {ipo.status}
                </span>
              </td>
              <td>
                <button className="update-btn" onClick={() => handleUpdate(index)}>Update</button>
              </td>
              <td>
                <button className="delete-btn" onClick={() => handleDelete(index)}>Delete</button>
                <button className="view-btn" onClick={() => handleView(index)}>View</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
      <div className="pagination">
        <button onClick={handlePrevPage} disabled={currentPage === 1}>
          &lt;
        </button>
        {pageNumbers.map(number => (
          <button
            key={number}
            className={currentPage === number ? 'active' : ''}
            onClick={() => handleClick(number)}
          >
            {number}
          </button>
        ))}
        <button onClick={handleNextPage} disabled={currentPage === pageNumbers.length}>
          &gt;
        </button>
      </div>
    </div>
  );
}

export default IPOList;

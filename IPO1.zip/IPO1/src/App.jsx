import React, { useState } from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Sidebar from '../components/Sidebar';
import Header from '../components/Header';
import IPOList from '../components/IPOList';
import IPOInfo from '../components/IPOInfo';
import './App.css';

function App() {
  const [searchTerm, setSearchTerm] = useState('');

  return (
    <Router>
      <div className="app">
        <Sidebar />
        <Header searchTerm={searchTerm} setSearchTerm={setSearchTerm} />
        <div className="main-content"> 
          <Routes>
            <Route path="/" element={<IPOList searchTerm={searchTerm} />} />
          </Routes>
          </div>
          <div className="main-content1">
          <Routes >
            <Route path="/ipo-info/:id" element={<IPOInfo />} />
          </Routes>
          </div>
      </div>
    </Router>
  );
}

export default App;
